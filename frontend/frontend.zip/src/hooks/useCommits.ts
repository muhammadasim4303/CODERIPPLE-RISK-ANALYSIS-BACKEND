/**
 * useCommits — GitHub commits with branch switching, risk loading and analysis.
 * Risk scores persisted in Firebase; loaded from cache first.
 */
import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import {
  listCommits, listBranches, getCommit,
  type GHCommit, type GHBranch,
} from '@/lib/githubService';
import { analyzeCommit, getCachedRisk, type RiskResult } from '@/lib/flaskService';
import {
  upsertRiskScore, getRiskScore, updateRepoStats,
  type FBRiskScore,
} from '@/lib/firebaseService';

export interface CommitRow extends GHCommit {
  risk?: RiskResult | null;
  isAnalyzing?: boolean;
}

export function useCommits(owner?: string, repo?: string) {
  const { user } = useAuth();
  const [commits, setCommits]           = useState<CommitRow[]>([]);
  const [branches, setBranches]         = useState<GHBranch[]>([]);
  const [currentBranch, setCurrentBranch] = useState('');
  const [isLoading, setIsLoading]       = useState(false);
  const [isBranchLoading, setIsBranchLoading] = useState(false);
  const [error, setError]               = useState<string | null>(null);

  // Load branches once
  useEffect(() => {
    if (!owner || !repo) return;
    setIsBranchLoading(true);
    listBranches(owner, repo)
      .then(setBranches)
      .catch(() => setBranches([]))
      .finally(() => setIsBranchLoading(false));
  }, [owner, repo]);

  const loadCommits = useCallback(async (branch?: string) => {
    if (!owner || !repo) return;
    setIsLoading(true);
    setError(null);
    try {
      const ghCommits = await listCommits(owner, repo, 1, branch || undefined);

      // Hydrate with cached risk scores
      const rows: CommitRow[] = await Promise.all(
        ghCommits.map(async (c): Promise<CommitRow> => {
          let risk: RiskResult | null = null;
          if (user) {
            const fb = await getRiskScore(user.id, c.sha);
            if (fb) {
              risk = {
                sha: fb.sha,
                risk_label: fb.risk_label,
                overall_risk_score: fb.overall_risk_score,
                correctness_risk: fb.correctness_risk,
                security_risk: fb.security_risk,
                maintainability_risk: fb.maintainability_risk,
                integration_risk: fb.integration_risk,
                risk_reasons: fb.risk_reasons,
                mode: fb.mode,
                added_lines: fb.additions,
                removed_lines: fb.deletions,
                files_touched: fb.files_changed,
              };
            } else {
              risk = await getCachedRisk(c.sha);
            }
          }
          return { ...c, risk };
        })
      );

      setCommits(rows);
    } catch (e) {
      setError(e instanceof Error ? e.message : 'Failed to load commits');
    } finally {
      setIsLoading(false);
    }
  }, [owner, repo, user]);

  useEffect(() => { loadCommits(currentBranch || undefined); }, [owner, repo, currentBranch]);

  const switchBranch = (branch: string) => {
    setCurrentBranch(branch);
    setCommits([]);
  };

  const runAnalysis = useCallback(async (sha: string): Promise<RiskResult | null> => {
    if (!owner || !repo || !user) return null;

    setCommits(prev => prev.map(c => c.sha === sha ? { ...c, isAnalyzing: true } : c));
    try {
      const full = await getCommit(owner, repo, sha);
      const result = await analyzeCommit(sha, full.commit.message, full.files ?? []);

      // Persist to Firebase
      const score: Omit<FBRiskScore, 'userId'> = {
        sha,
        repoFullName: `${owner}/${repo}`,
        branch: currentBranch || 'default',
        message: full.commit.message,
        author_name: full.commit.author.name,
        author_avatar: full.author?.avatar_url ?? '',
        committed_at: full.commit.author.date,
        risk_label: result.risk_label,
        overall_risk_score: result.overall_risk_score,
        correctness_risk: result.correctness_risk ?? 0,
        security_risk: result.security_risk ?? 0,
        maintainability_risk: result.maintainability_risk ?? 0,
        integration_risk: result.integration_risk ?? 0,
        risk_reasons: result.risk_reasons ?? [],
        files_changed: result.files_touched ?? 0,
        additions: result.added_lines ?? 0,
        deletions: result.removed_lines ?? 0,
        mode: result.mode ?? 'model',
        analyzed_at: new Date().toISOString(),
      };
      await upsertRiskScore(user.id, score);

      setCommits(prev => prev.map(c => c.sha === sha ? { ...c, risk: result, isAnalyzing: false } : c));
      return result;
    } catch (e) {
      setCommits(prev => prev.map(c => c.sha === sha ? { ...c, isAnalyzing: false } : c));
      throw e;
    }
  }, [owner, repo, user, currentBranch]);

  return {
    commits, branches, currentBranch,
    isLoading, isBranchLoading, error,
    switchBranch, runAnalysis,
    refresh: () => loadCommits(currentBranch || undefined),
  };
}

/**
 * useRepositories — fetches GitHub repos live, persists to Firebase,
 * and merges risk stats. Gracefully falls back to Firebase cache on errors.
 */
import { useState, useEffect, useCallback } from 'react';
import { useAuth } from '@/context/AuthContext';
import { listRepos as listGHRepos, type GHRepo } from '@/lib/githubService';
import { upsertRepo, listRepos as fbListRepos, type FBRepo } from '@/lib/firebaseService';

export type Repository = FBRepo & { html_url?: string; topics?: string[]; pushed_at?: string };

function ghToFB(r: GHRepo, userId: string): Omit<FBRepo, 'userId'> {
  return {
    id: String(r.id),
    name: r.name,
    full_name: r.full_name,
    description: r.description,
    private: r.private,
    language: r.language,
    stars_count: r.stargazers_count,
    forks_count: r.forks_count,
    open_issues_count: r.open_issues_count,
    default_branch: r.default_branch,
    average_risk_score: 0,
    total_commits_analyzed: 0,
    high_risk_commits_count: 0,
    medium_risk_commits_count: 0,
    low_risk_commits_count: 0,
    last_analyzed_at: null,
    created_at: r.created_at,
    updated_at: r.updated_at,
  };
}

export function useRepositories() {
  const { user } = useAuth();
  const [repositories, setRepositories] = useState<Repository[]>([]);
  const [isLoading, setIsLoading]       = useState(true);
  const [error, setError]               = useState<string | null>(null);

  const fetch = useCallback(async () => {
    if (!user) { setIsLoading(false); return; }
    setIsLoading(true);
    setError(null);

    // Always try Firebase cache first so UI isn't empty on CORS errors
    const fbCached = await fbListRepos(user.id);

    try {
      // Fetch live from GitHub
      const ghRepos = await listGHRepos();

      // Persist to Firebase (silently ignores adblock)
      await Promise.all(ghRepos.map(r => upsertRepo(user.id, ghToFB(r, user.id))));

      // Read back merged data (risk stats etc.)
      const fbRepos = await fbListRepos(user.id);
      const fbMap   = new Map(fbRepos.map(r => [r.full_name, r]));

      const merged: Repository[] = ghRepos.map(gh => ({
        ...(fbMap.get(gh.full_name) ?? ghToFB(gh, user.id)),
        userId: user.id,
        // always use live GH values for these
        stars_count: gh.stargazers_count,
        forks_count: gh.forks_count,
        open_issues_count: gh.open_issues_count,
        html_url: gh.html_url,
        topics: gh.topics,
        pushed_at: gh.pushed_at,
      }));

      setRepositories(merged);
    } catch (err) {
      const msg = err instanceof Error ? err.message : 'Failed to load repositories';

      // If it's a CORS / network error, show cached Firebase data if available
      if (fbCached.length > 0) {
        setRepositories(fbCached.map(r => ({ ...r })));
        setError(`GitHub unreachable (${msg}). Showing cached data.`);
      } else {
        setError(msg);
      }
    } finally {
      setIsLoading(false);
    }
  }, [user]);

  useEffect(() => { fetch(); }, [fetch]);

  const getRepository = useCallback(
    (id: string) =>
      repositories.find(r => r.id === id || r.full_name === id || r.name === id),
    [repositories],
  );

  return { repositories, isLoading, error, getRepository, refetch: fetch };
}

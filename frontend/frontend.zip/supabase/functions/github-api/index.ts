/**
 * Supabase Edge Function: github-api
 * Proxies GitHub API calls using the user's OAuth token.
 * Handles CORS so localhost dev works.
 */

import { serve } from "https://deno.land/std@0.177.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

// ─── CORS headers ─────────────────────────────────────────────────────────────
// Allow any origin in dev; tighten to your domain in production
const CORS_HEADERS = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
  "Access-Control-Allow-Headers":
    "Authorization, apikey, Content-Type, x-client-info",
};

function corsResponse(body: unknown, status = 200) {
  return new Response(JSON.stringify(body), {
    status,
    headers: { ...CORS_HEADERS, "Content-Type": "application/json" },
  });
}

function errorResponse(message: string, status = 400) {
  return corsResponse({ error: message }, status);
}

// ─── GitHub API helper ────────────────────────────────────────────────────────
async function ghFetch(path: string, token: string) {
  const url = path.startsWith("https://")
    ? path
    : `https://api.github.com${path}`;

  const res = await fetch(url, {
    headers: {
      Authorization: `Bearer ${token}`,
      Accept: "application/vnd.github+json",
      "X-GitHub-Api-Version": "2022-11-28",
      "User-Agent": "CodeRipple/1.0",
    },
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body?.message ?? `GitHub error ${res.status}`);
  }
  return res.json();
}

// ─── Main handler ─────────────────────────────────────────────────────────────
serve(async (req) => {
  // Handle CORS preflight — this is what was missing
  if (req.method === "OPTIONS") {
    return new Response(null, { status: 204, headers: CORS_HEADERS });
  }

  try {
    // Extract JWT from Authorization header
    const authHeader = req.headers.get("Authorization") ?? "";
    const jwt = authHeader.replace("Bearer ", "").trim();
    if (!jwt) return errorResponse("Missing Authorization header", 401);

    // Create Supabase client and get user
    // const supabase = createClient(
    //   Deno.env.get("SUPABASE_URL")!,
    //   Deno.env.get("SUPABASE_ANON_KEY")!,
    //   { global: { headers: { Authorization: `Bearer ${jwt}` } } }
    // );

    // New: Use service role for admin actions
    const supabase = createClient(
      Deno.env.get("VITE_SUPABASE_URL")!,
      Deno.env.get("VITE_SUPABASE_SERVICE_ROLE_KEY")!
    );

    const {
      data: { user },
      error: userError,
    } = await supabase.auth.getUser(jwt);
    if (userError || !user)
      return errorResponse("Unauthorized", 401);

    // Get GitHub OAuth token from provider token
    const {
      data: { session },
    } = await supabase.auth.getSession();

    // Try provider token from session, fall back to identity
    let githubToken =
      session?.provider_token ??
      user.identities?.find((i) => i.provider === "github")
        ?.identity_data?.access_token;

    if (!githubToken) {
      // Last resort: check user metadata
      githubToken = user.user_metadata?.provider_token;
    }

    if (!githubToken) {
      return errorResponse(
        "No GitHub token found. Please sign in with GitHub OAuth.",
        403
      );
    }

    // Parse action from query string
    const url = new URL(req.url);
    const action = url.searchParams.get("action") ?? "";
    const owner = url.searchParams.get("owner") ?? "";
    const repo = url.searchParams.get("repo") ?? "";
    const sha = url.searchParams.get("sha") ?? "";
    const page = url.searchParams.get("page") ?? "1";
    const perPage = url.searchParams.get("per_page") ?? "30";
    const sort = url.searchParams.get("sort") ?? "updated";
    const state = url.searchParams.get("state") ?? "open";
    const branch = url.searchParams.get("sha") ?? ""; // sha doubles as branch ref

    switch (action) {
      case "list-repos": {
        const data = await ghFetch(
          `/user/repos?per_page=${perPage}&page=${page}&sort=${sort}&affiliation=owner,collaborator,organization_member`,
          githubToken
        );
        return corsResponse(data);
      }

      case "list-branches": {
        if (!owner || !repo) return errorResponse("owner and repo required");
        const data = await ghFetch(
          `/repos/${owner}/${repo}/branches?per_page=100`,
          githubToken
        );
        return corsResponse(data);
      }

      case "list-commits": {
        if (!owner || !repo) return errorResponse("owner and repo required");
        let path = `/repos/${owner}/${repo}/commits?per_page=${perPage}&page=${page}`;
        if (branch) path += `&sha=${branch}`;
        const data = await ghFetch(path, githubToken);
        return corsResponse(data);
      }

      case "get-commit": {
        if (!owner || !repo || !sha)
          return errorResponse("owner, repo, and sha required");
        const data = await ghFetch(
          `/repos/${owner}/${repo}/commits/${sha}`,
          githubToken
        );
        return corsResponse(data);
      }

      case "list-issues": {
        if (!owner || !repo) return errorResponse("owner and repo required");
        const data = await ghFetch(
          `/repos/${owner}/${repo}/issues?state=${state}&per_page=${perPage}&page=${page}`,
          githubToken
        );
        return corsResponse(data);
      }

      case "get-user": {
        const data = await ghFetch("/user", githubToken);
        return corsResponse(data);
      }

      default:
        return errorResponse(`Unknown action: ${action}`);
    }
  } catch (err) {
    console.error("Edge function error:", err);
    return errorResponse(
      err instanceof Error ? err.message : "Internal error",
      500
    );
  }
});
